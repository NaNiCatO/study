dict = {"1":[1,2]}
print(dict["1"][0])
l = [1,2,3,4,5,6,7,8]
print(l[0])

for i,j in enumerate(dict.values()):
    print(i,j)