x = "-1"
p = eval(x)
print(p)