number_loop = int(input())

def print_hello(loop_n):
    for _ in range(loop_n):
        print("Hello, World!")

print_hello(number_loop)
